import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Course } from '../../shared/course';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.scss']
})
export class AddCourseComponent implements OnInit {
  courseForm!: FormGroup;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private dataService: DataService
  ) {}

  ngOnInit(): void {
    this.createForm();
  }

  createForm(): void {
    this.courseForm = this.formBuilder.group({
      name: ['', Validators.required],
      duration: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.courseForm.valid) {
      const course: Course = this.courseForm.value;
      this.dataService.addCourse(course).subscribe(() => {
        // After adding the course, navigate back to the course listing page
        this.router.navigate(['/courses']);
      });
    } else {
      console.log('Form is invalid');
    }
  }

  cancel(): void {
    // Navigate to Course Listing page without making changes
    this.router.navigate(['/courses']);
  }
}