import { Component, OnInit } from '@angular/core';
import { Course } from '../../shared/course';
import { DataService } from '../../services/data.service';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.scss']
})
export class CoursesComponent implements OnInit {
  courses: Course[] = [];

  constructor(private dataService: DataService, private router: Router) {} 

  ngOnInit(): void {
    this.getCourses();
  }

  getCourses() {
    this.dataService.getCourses().subscribe(result => {
      let courseList: any[] = result;
      courseList.forEach((element)=>{
        this.courses.push(element);
      });
      this.courses.reverse();
  });
  }
  deleteCourse(courseId: number) {
    this.dataService.deleteCourse(courseId).subscribe(() => {
      // Course deleted, reload the list of courses
      this.getCourses();
    });
  }

  editCourse(courseId: number) {
    // Navigate to the edit course page with the courseId as a parameter
    this.router.navigate(['/edit-course', courseId]);
  }
}
