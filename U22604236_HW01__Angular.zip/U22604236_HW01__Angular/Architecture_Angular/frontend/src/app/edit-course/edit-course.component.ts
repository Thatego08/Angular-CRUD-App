import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { Course } from '../shared/course';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.scss']
})
export class EditCourseComponent implements OnInit {
  courseId!: number;
  course: Course = { courseId: 0, name: '', duration: '', description: '' };
  courseForm!: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private dataService: DataService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.courseId = +params['id']; // Convert id to number
  
      // Fetch course details including the name using courseId
      this.dataService.getCourse(this.courseId).subscribe(course => {
        if (course) {
          this.course = course;
          console.log('Fetched course:', this.course); // Log fetched course data
          
          // Move createForm() call here
          this.createForm();
        } else {
          console.error('Course not found');
        }
      });
    });
  }
  
  createForm(): void {
    this.courseForm = this.formBuilder.group({
      name: [this.course.name, Validators.required],
      duration: [this.course.duration, Validators.required],
      description: [this.course.description, Validators.required]
    });
  }

  onSubmit(): void {
    if (this.courseForm.valid) {
      const updatedCourseData = this.courseForm.value;
      
      
      this.dataService.updateCourse(this.courseId, updatedCourseData).subscribe(
        () => {
          console.log('Course updated successfully');
         
          this.router.navigate(['/courses']);
        },
        error => {
          console.error('Error updating course:', error);
          // Handle error appropriately (e.g., display an error message)
        }
      );
    } else {
      console.log('Form is invalid');
      // Display a message to the user indicating that the form is invalid
    }
  }
  

  cancel(): void {
    // Redirect to the course listing page without making changes
    this.router.navigate(['/courses']);
  }
}

