// course.model.ts

export interface Course {
    courseId: number;
    name: string;
    description: string;
    duration: string;
  }
  