import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Course } from '../shared/course';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private apiUrl = 'https://localhost:7049/api/';
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) {}

  /// Get all courses
  getCourses(): Observable<Course[]> {
    return this.httpClient.get<Course[]>(`${this.apiUrl}Course/GetAllCourses`);
  }

  // Get a single course by ID
  getCourse(courseId: number): Observable<Course | null> {
    return this.getCourses().pipe(
      map(courses => courses.find(course => course.courseId === courseId) || null)
    );
  }

  // Add a new course
  addCourse(course: any): Observable<any> {
    return this.httpClient.post(`${this.apiUrl}Course/AddCourse`, course, this.httpOptions)
      .pipe(map(result => result));
  }

  // Update a course
  updateCourse(courseId: number, updatedCourse: any): Observable<any> {
    return this.httpClient.put(`${this.apiUrl}Course/UpdateCourse/${courseId}`, updatedCourse, this.httpOptions)
      .pipe(map(result => result));
  }
  

  // Delete a course
  deleteCourse(courseId: number): Observable<any> {
    return this.httpClient.post(`${this.apiUrl}Course/DeleteCourse/${courseId}`, {});
  }
}
