﻿using System.Threading.Tasks;

namespace Architecture_API.Models
{
    public interface ICourseRepository
    {
        Task<Course[]> GetAllCoursesAsync();
        Task<Course> GetCourseByIdAsync(int id);
        Task AddCourseAsync(Course course);
        Task UpdateCourseAsync(Course course);
        Task DeleteCourseAsync(int id);
    }
}
